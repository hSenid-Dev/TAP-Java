package com.hms.sample.sms.util;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;

import java.util.logging.Logger;

public class mainMenu {

    private final static Logger LOGGER = Logger.getLogger(mainMenu.class.getName());

    public static void main(String[] args) throws Exception {
        Server server = new Server(5556); 
        WebAppContext webapp = new WebAppContext();
        webapp.setContextPath("/");
        webapp.setWar("../lib/sdp-hello-world-app.war");
        server.setHandler(webapp);
        LOGGER.info("Application starting ...");
        server.start();
        server.join();
    }

}
