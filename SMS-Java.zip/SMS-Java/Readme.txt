This is a sample application
If you send your ID number after a keyword, you will received a messesage stating Male or Female

KEYWORD <space> NIC