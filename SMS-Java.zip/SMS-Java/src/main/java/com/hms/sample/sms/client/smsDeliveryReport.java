package com.hms.sample.sms.client;

import hms.kite.samples.api.sms.MoSmsDeliveryReportListener;
import hms.kite.samples.api.sms.messages.MoSmsDeliveryReportReq;

import java.util.logging.Logger;

public class smsDeliveryReport implements MoSmsDeliveryReportListener {


    private final static Logger LOGGER = Logger.getLogger(smsDeliveryReport.class.getName());

//    @Override
    public void onReceivedDeliveryReport(MoSmsDeliveryReportReq moDeliveryReportReq) {

        LOGGER.info("==> Sms delivery report received from SDP : "+ moDeliveryReportReq);

    }
}
